exports.allmenu = (prefix) => {
return `*OTHER MENU*
 *•* ${prefix}ping
 *•* ${prefix}simi
 *•* ${prefix}rules
 *•* ${prefix}listpc
 *•* ${prefix}listgc
 *•* ${prefix}script
 *•* ${prefix}owner
 *•* ${prefix}confes
 *•* ${prefix}menfes
 *•* ${prefix}runtime

 *TOOLS MENU*
 *•* ${prefix}tts
 *•* ${prefix}isgd
 *•* ${prefix}cuttly
 *•* ${prefix}tinyurl
 *•* ${prefix}nulis
 *•* ${prefix}toimg
 *•* ${prefix}obfus
 *•* ${prefix}ssweb
 *•* ${prefix}kalkulator

 *SET PROSES/DONE*
 *•* ${prefix}setdone
 *•* ${prefix}changedone
 *•* ${prefix}delsetdone
 *•* ${prefix}setproses
 *•* ${prefix}delsetproses
 *•* ${prefix}changeproses

 *STORE MENU*
 *•* ${prefix}list
 *•* ${prefix}addlist
 *•* ${prefix}dellist
 *•* ${prefix}done
 *•* ${prefix}proses
 *•* ${prefix}kali
 *•* ${prefix}bagi
 *•* ${prefix}kurang
 *•* ${prefix}tambah

 *TOPUP GAMES*
 *•* ${prefix}topupff 
 *•* ${prefix}topupml

 *GROUP MENU*
 *•* ${prefix}add
 *•* ${prefix}kick
 *•* ${prefix}open
 *•* ${prefix}close
 *•* ${prefix}group
 *•* ${prefix}tagall
 *•* ${prefix}delete
 *•* ${prefix}revoke
 *•* ${prefix}antilink
 *•* ${prefix}hidetag
 *•* ${prefix}demote
 *•* ${prefix}setdesc
 *•* ${prefix}linkgrup
 *•* ${prefix}promote
 *•* ${prefix}setppgrup
 *•* ${prefix}setnamegc

 *OWNER MENU*
 *•* ${prefix}bc
 *•* ${prefix}leave
 *•* ${prefix}creategc
 *•* ${prefix}sendsesi
 *•* ${prefix}setppbot
 *•* ${prefix}broadcast
 *•* ${prefix}bugpc *628xxx*
 *•* ${prefix}sendbug *628xxx*

 *KERANG AJAIB*
 *•* ${prefix}rate
 *•* ${prefix}apakah
 *•* ${prefix}bisakah
 *•* ${prefix}siapakah
 *•* ${prefix}bagaimanakah

 *DOWNLOADER*
 *•* ${prefix}play
 *•* ${prefix}tiktok
 *•* ${prefix}ytmp3
 *•* ${prefix}ytmp4
 *•* ${prefix}gitclone
 *•* ${prefix}mediafire`
}